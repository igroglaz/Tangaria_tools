https://translator.gres.biz/
https://github.com/OneMoreGres/ScreenTranslator

Windows:
C:/Users/user-name/AppData/Roaming/Gres/ScreenTranslator/assets/tessdata

Linux:
/home/user-name/.local/share/Gres/ScreenTranslator/assets/tessdata
